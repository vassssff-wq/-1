# Messenger Prototype (Flutter + Firebase)

Этот проект — минимальный мессенджер на Flutter, используя Firebase (Auth, Firestore, Storage).
Поддерживает: текст, изображения, аватары, голосовые сообщения, приватные чаты.

## Как запустить

1. Установи Flutter и Android Studio.
2. Открой проект в Android Studio или VS Code.
3. Скопируй `google-services.json` в `android/app/` (создай проект в Firebase и добавь Android app).
4. Выполни в терминале: `flutter pub get`
5. Запусти на устройстве или эмуляторе: `flutter run`

## Сборка релизного APK

1. Создай keystore: 
   `keytool -genkey -v -keystore ~/keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
2. Помести keystore и настрой `android/key.properties` (пример ниже).
3. Выполни: `flutter build apk --release`
4. APK будет в `build/app/outputs/flutter-apk/app-release.apk`

## Примечания

- Добавь свои правила безопасности в Firestore и Storage перед публикацией.
- Заменяй зависимости в `pubspec.yaml` под нужную версию Flutter SDK при необходимости.
