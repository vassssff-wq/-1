// Полный, но компактный пример: аутентификация, список пользователей, личные чаты,
// отправка текста, изображений, голосовых сообщений, аватары.

import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Messenger Prototype',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: EntryPage(),
    );
  }
}

class EntryPage extends StatefulWidget {
  @override
  _EntryPageState createState() => _EntryPageState();
}

class _EntryPageState extends State<EntryPage> {
  final _nameController = TextEditingController();
  bool _loading = false;

  Future<void> _start() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;
    setState(() => _loading = true);

    final auth = FirebaseAuth.instance;
    User? user = auth.currentUser;
    if (user == null) {
      final cred = await auth.signInAnonymously();
      user = cred.user;
    }

    if (user != null) {
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'name': name,
        'lastSeen': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => UsersListPage()),
      );
    }

    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Добро пожаловать')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Введите ваше имя (будет видно друзьям)'),
            SizedBox(height: 12),
            TextField(controller: _nameController),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _loading ? null : _start, child: _loading ? CircularProgressIndicator() : Text('Войти')),
          ],
        ),
      ),
    );
  }
}

class UsersListPage extends StatelessWidget {
  final uid = FirebaseAuth.instance.currentUser?.uid;

  Future<void> _setAvatar(BuildContext context) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, maxWidth: 800);
    if (picked == null) return;

    final file = File(picked.path);
    final storageRef = FirebaseStorage.instance.ref().child('avatars').child('$uid.jpg');
    await storageRef.putFile(file);
    final url = await storageRef.getDownloadURL();
    await FirebaseFirestore.instance.collection('users').doc(uid).set({'avatarUrl': url}, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    final usersRef = FirebaseFirestore.instance.collection('users');
    return Scaffold(
      appBar: AppBar(
        title: Text('Пользователи'),
        actions: [
          IconButton(icon: Icon(Icons.person), onPressed: () => _setAvatar(context)),
          IconButton(icon: Icon(Icons.logout), onPressed: () async { await FirebaseAuth.instance.signOut(); Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => EntryPage())); }),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: usersRef.snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index];
              final otherId = data.id;
              final name = data['name'] ?? 'Anon';
              final avatar = data['avatarUrl'] as String?;
              if (otherId == uid) return ListTile(
                leading: avatar != null ? CircleAvatar(backgroundImage: NetworkImage(avatar)) : CircleAvatar(child: Icon(Icons.person)),
                title: Text('$name (вы)'),
                subtitle: Text('ID: $otherId'),
              );
              return ListTile(
                leading: avatar != null ? CircleAvatar(backgroundImage: NetworkImage(avatar)) : CircleAvatar(child: Icon(Icons.person)),
                title: Text(name),
                subtitle: Text('ID: $otherId'),
                onTap: () {
                  final chatId = _makeChatId(uid!, otherId);
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatPage(chatId: chatId, otherId: otherId, otherName: name, otherAvatar: avatar)));
                },
              );
            },
          );
        },
      ),
    );
  }

  String _makeChatId(String a, String b) {
    final list = [a, b]..sort();
    return '${list[0]}_${list[1]}';
  }
}

class ChatPage extends StatefulWidget {
  final String chatId;
  final String otherId;
  final String otherName;
  final String? otherAvatar;
  ChatPage({required this.chatId, required this.otherId, required this.otherName, this.otherAvatar});
  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _textController = TextEditingController();
  final _scrollController = ScrollController();
  final uid = FirebaseAuth.instance.currentUser?.uid;
  final recorder = Record();
  final player = AudioPlayer();
  bool _recording = false;

  String _formatTimestamp(Timestamp? ts) {
    if (ts == null) return '';
    return DateFormat('HH:mm').format(ts.toDate());
  }

  Future<void> _sendText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages').add({
      'type': 'text',
      'text': text,
      'senderId': uid,
      'senderName': await _myName(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    _textController.clear();
    await Future.delayed(Duration(milliseconds: 100));
    _scrollController.animateTo(_scrollController.position.maxScrollExtent + 100, duration: Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  Future<String?> _myName() async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    return doc['name'] as String? ?? 'Me';
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, maxWidth: 1200);
    if (picked == null) return;
    final file = File(picked.path);
    final id = Uuid().v4();
    final ref = FirebaseStorage.instance.ref().child('chat_images').child('${widget.chatId}_$id.jpg');
    final upload = await ref.putFile(file);
    final url = await ref.getDownloadURL();
    await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages').add({
      'type': 'image',
      'mediaUrl': url,
      'senderId': uid,
      'senderName': await _myName(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<String> _localFilePath() async {
    final dir = await getTemporaryDirectory();
    return '${dir.path}/${Uuid().v4()}.m4a';
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final path = await recorder.stop();
      setState(() => _recording = false);
      if (path == null) return;
      final file = File(path);
      final id = Uuid().v4();
      final ref = FirebaseStorage.instance.ref().child('chat_audio').child('${widget.chatId}_$id.m4a');
      await ref.putFile(file);
      final url = await ref.getDownloadURL();
      await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages').add({
        'type': 'audio',
        'mediaUrl': url,
        'senderId': uid,
        'senderName': await _myName(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      final has = await recorder.hasPermission();
      if (!has) return; // можно показать диалог
      final path = await _localFilePath();
      await recorder.start(path: path, encoder: AudioEncoder.aacLc, bitRate: 128000);
      setState(() => _recording = true);
    }
  }

  Future<void> _playUrl(String url) async {
    try {
      await player.setUrl(url);
      player.play();
    } catch (e) {
      print('play error: $e');
    }
  }

  @override
  void dispose() {
    player.dispose();
    recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messagesRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages').orderBy('createdAt');
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          widget.otherAvatar != null ? CircleAvatar(backgroundImage: NetworkImage(widget.otherAvatar!), radius: 16) : CircleAvatar(child: Icon(Icons.person), radius: 16),
          SizedBox(width: 8),
          Text(widget.otherName),
        ]),
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: messagesRef.snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              return ListView.builder(
                controller: _scrollController,
                itemCount: docs.length,
                itemBuilder: (context, index) {
                  final data = docs[index];
                  final type = data['type'] as String? ?? 'text';
                  final sender = data['senderName'] ?? 'Anon';
                  final createdAt = data['createdAt'] as Timestamp?;
                  final isMe = data['senderId'] == uid;
                  Widget content;
                  if (type == 'text') {
                    content = Text(data['text'] ?? '');
                  } else if (type == 'image') {
                    final url = data['mediaUrl'] as String?;
                    content = url != null ? Image.network(url, width: 200) : SizedBox();
                  } else if (type == 'audio') {
                    final url = data['mediaUrl'] as String?;
                    content = Row(children: [
                      IconButton(icon: Icon(Icons.play_arrow), onPressed: url != null ? () => _playUrl(url) : null),
                      Text('Аудио')
                    ]);
                  } else {
                    content = SizedBox();
                  }

                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Column(
                        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                        children: [
                          Text(sender, style: TextStyle(fontSize: 12, color: Colors.grey)),
                          Container(
                            decoration: BoxDecoration(color: isMe ? Colors.blue[200] : Colors.grey[300], borderRadius: BorderRadius.circular(8)),
                            padding: EdgeInsets.all(10),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [content, SizedBox(height: 6), Text(_formatTimestamp(createdAt), style: TextStyle(fontSize: 10, color: Colors.black54))]),
                          )
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8),
            child: Row(children: [
              IconButton(icon: Icon(Icons.image), onPressed: _sendImage),
              IconButton(icon: Icon(_recording ? Icons.mic : Icons.mic_none), onPressed: _toggleRecord),
              Expanded(
                child: TextField(controller: _textController, decoration: InputDecoration(hintText: 'Напишите сообщение...', border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)), contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)), onSubmitted: (_) => _sendText()),
              ),
              SizedBox(width: 8),
              ElevatedButton(onPressed: _sendText, child: Icon(Icons.send)),
            ]),
          ),
        )
      ]),
    );
  }
}
